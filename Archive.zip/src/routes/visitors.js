/**
 * index
 */

"use strict";


/* Node modules */


/* Third-party modules */


/* Files */


export class Visitors {


    constructor (visitorService, logger) {
        this._visitorService = visitorService;
        this._logger = logger;
    }

    get () {
        return [
            (req, res) => {

                this._visitorService.processGetRequest(req.params.id)

                    .then(result => {
                        let row = result.rows;
                        res.send({success : 1, message : "completed", data : {row}, retry: 0});

                    })
                    .catch(err => {
                        this._logger.error(err);
                        res.send({success : 0, message : "Error!", data : JSON.stringify(err), retry: 1});

                    });
            }
        ];
    }

    post () {
        return [
            (req, res) => {

                this._visitorService.processRequest(req.params)

                    .then(result => {

                        res.send({success : 1, message : "completed", data : {}, retry: 0});

                    })
                    .catch(err => {
                        this._logger.error(err);
                        res.send({success : 0, message : "Error!", data : JSON.stringify(err), retry: 1});

                    });
            }
        ];
    }


    put () {
        return [
            (req, res) => {

                // console.log(req.params);
                // console.log(req.body);
                // process.exit();

                this._visitorService.processPutRequest(req.params.id, req.params)

                    .then(result => {

                        res.send({success : 1, message : "completed", data : {}, retry: 0});

                    })
                    .catch(err => {
                        this._logger.error(err);
                        res.send({success : 0, message : "Error!", data : JSON.stringify(err), retry: 1});

                    });
            }
        ];
    }

}
