/**
 * customerRequest
 */

"use strict";

/* Third-party modules */
import {_} from "lodash";

export class VisitorStore {

    constructor(resource, eventListener, logger) {
        this._resource = resource;
        this._eventListener = eventListener;
        this._logger = logger;
    }

    saveCustomer(customer) {

        this._logger.info(
            "Checking if customer exist in the Merlin Database -> Account Number: " + customer["cust_account"]
        );

                let selectQuery = "SELECT * FROM public.customer WHERE company = $1 AND depot = $2 AND account = $3 LIMIT 1";
                let args = [
                    customer["cust_company"],
                    customer["cust_depot"],
                    customer["cust_account"]
                ];
        this._logger.info("Checking for public customer" + JSON.stringify(args));
        return this._resource.query(selectQuery, args)
            .then(response => {

                if (response.rowCount > 0) {

                    this._logger.info("Checking if customer exist in the API table (api.cm_request)");

                    let fieldsToCheck = {
                        "cust_name": "name",
                        "cust_add1": "add1",
                        "cust_add2": "add2",
                        "cust_city": "city",
                        "cust_county": "county",
                        "cust_country": "country",
                        "cust_country_code": "country_code",
                        "cust_postcode": "postcode",
                        "cust_email": "email",
                        "cust_telephone": "telephone"
                    };

                    if (!this.checkIfUpdateRequired(response.rows[0], customer, fieldsToCheck)) {

                        this._logger.info("Found a record on customers table so no update is required!");
                        let err = new Error("Update is not required!");
                        err.code = 101; // Made up error code.
                        throw err;

                    }

                    return "update";
                }

                let selectQuery = `
                    SELECT
                        *
                    FROM
                        api.cm_requests
                    WHERE
                        company = $1
                    AND
                        depot = $2
                    AND
                        cust_account = $3
                    AND
                        (cm_status = 'complete' OR cm_status = 'ready')
                    LIMIT 1
                `;
                let args = [
                    customer["cust_company"],
                    customer["cust_depot"],
                    customer["cust_account"]
                ];
                this._logger.info("Checking if customer exists in cm_request table" + JSON.stringify(args));
                return this._resource.query(selectQuery, args).then((response) => {

                    if (response.rowCount > 0) {

                        this._logger.info("Customer found in (api.cm_request) so updating customer details");

                        let fieldsToCheck = {
                            "cust_name":    "cust_name",
                            "cust_add1":    "cust_add1",
                            "cust_add2":    "cust_add2",
                            "cust_city":    "cust_city",
                            "cust_county":  "cust_county",
                            "cust_country": "cust_country",
                            "cust_country_code": "cust_country_code",
                            "cust_postcode":  "cust_postcode",
                            "cust_email":     "cust_email",
                            "cust_telephone": "cust_telephone"
                        };

                        if (!this.checkIfUpdateRequired(response.rows[0], customer, fieldsToCheck)) {

                            this._logger.info("Found a record on api.cm_requests table so no update is required!");
                            let err = new Error("Update is not required!");
                            err.code = 101; // Made up error code.
                            throw err;

                        }

                        return "update";
                    }

                    this._logger.info("Updating or inserting new customer");
                    return "insert";

                });
            })
            .then(action => {

                // Insert or Update Customer
                let insertQuery = `
                    INSERT INTO
                    api.cm_requests (
                        cm_action,
                        cm_status,
                        company,
                        depot,
                        cust_company,
                        cust_depot,
                        cust_account,
                        cust_name,
                        cust_add1,
                        cust_add2,
                        cust_city,
                        cust_county,
                        cust_country,
                        cust_country_code,
                        cust_postcode,
                        cust_email,
                        cust_currency_code,
                        cust_telephone,
                        cust_delivery_code
                    )
                    VALUES (
                        $1,
                        $2,
                        $3,
                        $4,
                        $5,
                        $6,
                        $7,
                        $8,
                        $9,
                        $10,
                        $11,
                        $12,
                        $13,
                        $14,
                        $15,
                        $16,
                        $17,
                        $18,
                        $19
                    )
                    RETURNING cm_request_id
                `;

                let args = [
                    action,
                    customer["cm_status"],
                    customer["company"],
                    customer["depot"],
                    customer["cust_company"],
                    customer["cust_depot"],
                    customer["cust_account"],
                    customer["cust_name"],
                    customer["cust_add1"],
                    customer["cust_add2"],
                    customer["cust_city"],
                    customer["cust_county"],
                    customer["cust_country"],
                    customer["cust_country_code"],
                    customer["cust_postcode"],
                    customer["cust_email"],
                    customer["cust_currency_code"],
                    customer["cust_telephone"],
                    customer["cust_delivery_code"]
                ];

                return this._resource.query(insertQuery, args);
            })
            .then(result => {

                this._logger.info("Customer insert complete");
                this._logger.info(
                    "Listening for notification on merlin_customer_creation_" + result.rows[0]["cm_request_id"]
                );
                let listenQuery = "LISTEN merlin_customer_creation_" + result.rows[0]["cm_request_id"];
                return this._resource.query(listenQuery, []).then(() => {
                    return result;
                });

            })
            .then((result) => {

                return this._eventListener.newChannel("merlin_customer_creation_" + result.rows[0]["cm_request_id"])
                    .then((response) => {

                        this._logger.info(
                            "Notification Received merlin_customer_creation_" + result.rows[0]["cm_request_id"]
                        );

                        var message = JSON.parse(response);
                        let customerData = JSON.parse(message.payload);

                        if (customerData.success === 1) {
                            return result.rows[0]["cm_request_id"];
                        }

                        throw new Error(customerData.message);
                    });
            });
    }

    checkIfUpdateRequired(merlinCustomerData, customerData, fieldsToCheck) {

        let updateRequired = false;
        _.forEach(fieldsToCheck, (value, key) => {

            if (!customerData[key]) {
                customerData[key] = "";
            }

            if (customerData[key] !== merlinCustomerData[value]) {
                updateRequired = true;
            }

        });

        return updateRequired;
    }

}
