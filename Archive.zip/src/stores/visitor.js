/**
 * customerRequest
 */

"use strict";

/* Third-party modules */
import {_} from "lodash";
var base64 = require('node-base64-image');

export class VisitorStore {

    constructor(resource, logger) {
        this._resource = resource;
        this._logger = logger;
    }

    saveCustomer(customer) {

       // if(customer.paramImagePath != ''){
            var unix = Math.round(+new Date()/1000);
            var options = {filename: '/Users/aroras/Desktop/merlin-handler/images/' + customer.paramAccountName +'_'+ unix +'.jpg'};
            var imageData = new Buffer(customer.paramImagePath, 'base64');

            base64.base64decoder(imageData, options, function (err, saved) {
                if (err) { console.log(err); }
                console.log(saved);
            });
        //}

        let insertQuery = `
                    INSERT INTO
                    public.cromwell_recp (
                        type,
                        accountid,
                        accountname,
                        contactid,
                        contactname,
                        employeeid,
                        employeename,
                        vehiclereg,
                        settime,
                        reclogid,
                        logid,
                        pendingid,
                        imagepath
                    )
                    VALUES (
                        $1,
                        $2,
                        $3,
                        $4,
                        $5,
                        $6,
                        $7,
                        $8,
                        $9,
                        $10,
                        $11,
                        $12,
                        $13
                    )
                    RETURNING id
                `;

        let args = [
            customer.paramType,
            customer.paramAccountId,
            customer.paramAccountName,
            customer.paramContactId,
            customer.paramContactName,
            customer.paramEmployeeId,
            customer.paramEmployeeName,
            customer.paramVehicleReg,
            customer.paramTime,
            customer.paramRecLogId,
            customer.paramLogId,
            customer.paramPendingId,
            options.filename
        ];
        return this._resource.query(insertQuery, args)
            .then(response => {
                return response;
            })
            .then(res => {

                let selectQuery = "SELECT * FROM public.cromwell_recp WHERE id = $1 LIMIT 1";
                let args = [
                    res.rows[0]["id"]
                ];

                return this._resource.query(selectQuery, args)
                    .then(data => {
                        return data.rows[0];
                    })
            });
    }

    getCustomer(id) {

        let selectQuery = "SELECT * FROM shiv.table1 WHERE id = $1 LIMIT 1";
        let args = [
            id
        ];

        return this._resource.query(selectQuery, args)
            .then(response => {
               return response;
            });
    }

    updateCustomer(id, customer) {

        console.log(id);
        console.log(customer);
        process.exit();

        let updateQuery = `
                    UPDATE
                    shiv.table1 SET 
                        type = $1,
                        accountid = $2,
                        accountname = $3,
                        contactid = $4,
                        contactname = $5,
                        employeeid = $6,
                        employeename = $7,
                        vehiclereg = $8,
                        settime = $9,
                        reclogid = $10,
                        logid = $11,
                        pendingid = $12,
                        imagepath = $13
                  
                    WHERE id = $14 
                `;

        let args = [
            customer.paramType,
            customer.paramAccountId,
            customer.paramAccountName,
            customer.paramContactId,
            customer.paramContactName,
            customer.paramEmployeeId,
            customer.paramEmployeeName,
            customer.paramVehicleReg,
            customer.paramTime,
            customer.paramRecLogId,
            customer.paramLogId,
            customer.paramPendingId,
            customer.paramImagePath,
            id
        ];
        return this._resource.query(updateQuery, args)
            .then(response => {
                return response;
            });
    }

    checkIfUpdateRequired(merlinCustomerData, customerData, fieldsToCheck) {

        let updateRequired = false;
        _.forEach(fieldsToCheck, (value, key) => {

            if (!customerData[key]) {
                customerData[key] = "";
            }

            if (customerData[key] !== merlinCustomerData[value]) {
                updateRequired = true;
            }

        });

        return updateRequired;
    }

}
