/**
 * app
 */

"use strict";

import config from "./config.json";
import restify from "restify";
import fs from "fs";

/* Files */
import {Logger} from "./lib/logger";
import {DataCleaner} from "./services/dataCleaner";
import {VisitorStore} from "./stores/visitor";
import {Visitors} from "./routes/visitors";
import {Postgres} from "./resources/postgres";
import {DbConnect} from "./resources/dbConnect";
import {EventListener} from "./services/eventListener";
import {VisitorService} from "./services/visitor";
import {TemplateManager} from "./services/templateManager";

let logger = new Logger();
let db = new DbConnect(config.db.postgres.string);

db.createConnection()
    .then((connection) => {
        let templateManager = new TemplateManager();
        let dataCleaner = new DataCleaner();
        //let emitter = new EventEmitter();
        let postgres = new Postgres(connection);
        let eventListener = new EventListener(connection, logger);
        let visitorStore = new VisitorStore(postgres, logger);
        let visitorService = new VisitorService(visitorStore, templateManager, dataCleaner, logger);
        let visitors = new Visitors(visitorService, logger);

        /* Start Listening */
        eventListener.listen();

        let server;
        /* Create the server instance */
        server = restify.createServer();

        server.use(restify.acceptParser(server.acceptable));
        server.use(restify.queryParser());
        server.use(restify.bodyParser({mapParams : true}));

        /* Define the routes */
        server.post("/visitors", visitors.post());
        server.get("/visitors/:id", visitors.get());
        server.put("/visitors/:id", visitors.put());

        /* Start up the server */
        server.listen(config.server.port, () => {
            logger.info("System Listen on port " + config.server.port);
        });

    }).catch((err) => {
        logger.fatal("Database Failure:  " +  err);
        process.exit();
    });
